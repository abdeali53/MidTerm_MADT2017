//
//  ViewController.swift
//  MADT_Test
//
//  Created by MacStudent on 2017-10-20.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var txtUsername: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnLogin(_ sender: Any) {
        if(txtUsername.text=="admin" && txtPassword.text=="admin")
        {
            //let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
           
            performSegue(withIdentifier: "gotoStudentEntry", sender: self)
            
            
            //let controller = storyBoard.instantiateViewController(withIdentifier: "someViewController")
            //self.present(controller, animated: true, completion: nil)
        }
        else{
            let alertpopup = UIAlertController(title: "Login", message: "Incorrect Username or Password", preferredStyle: .alert)
            let action = UIAlertAction(title: "Message", style: .default, handler: nil
            )
            alertpopup.addAction(action)
        }
    }
    
    
}

