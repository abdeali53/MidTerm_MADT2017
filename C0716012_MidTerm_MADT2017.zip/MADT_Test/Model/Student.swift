//
//  Student.swift
//  MADT_Test
//
//  Created by MacStudent on 2017-10-20.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import Foundation

class Student{
    
    var Id : Int!
    var Name : String!
    var DOB : Date!
    var EmailAddress : String!
    var Marks : [Float]
    
    init() {
        self.Id = 1
        self.DOB = Date()
        self.Marks = []
        self.Name = ""
        self.EmailAddress = ""
    }
    
    
}
